import operator


class Estadisticas:  # ESTADISTICAS DEL JUEGO
    def __init__(self):
        self.rango_edades = {"5,18": 0, "19,45": 0, "46,60": 0, "61,100": 0}
        self.puntos_generos = {"M": 0, "F": 0}
        self.promedio_disparos = 0
        self.top10 = []

    def imprimir_top(self, juegos, usuarios):  # IMPRIMIR TOP 10 DE LOS MEJORES JUEGOS
        self.top10_juegos(juegos)

    def imprimir_estadisticas(self, numero_juegos):  # IMPRIMIR ESTADISTICAS
        edades_ordenado = sorted(self.rango_edades.items(), key=operator.itemgetter(1))
        edades_ordenado.reverse()
        if numero_juegos > 0:
            print("La edad de los jugadores que mas juegan estan entre {} años".format(edades_ordenado[0][0]))
        else:
            print("La edad de los jugadores que mas juegan estan entre 0 años")
        print("Partidas por genero")
        print("M: {}".format(self.puntos_generos["M"]))
        print("F: {}".format(self.puntos_generos["F"]))
        if numero_juegos > 0:
            promedio = self.promedio_disparos / numero_juegos
        else:
            promedio = 0
        print(" Promedio de disparos realizados para ganar: ", promedio)

    def actualizar_estadisticas(self, juego):  # ACTUALIZACION DE LAS ESTADISTICAS DEL USUARIO
        # Rango de edades
        edad = juego.usuario.edad
        if 5 <= edad <= 18:
            self.rango_edades["5,18"] += 1
        elif 19 <= edad <= 45:
            self.rango_edades["19,45"] += 1
        elif 46 <= edad <= 60:
            self.rango_edades["46,60"] += 1
        elif 61 <= edad <= 100:
            self.rango_edades["61,100"] += 1

        # Generos
        genero = juego.usuario.genero
        self.puntos_generos[genero] += 1

        # Promedio de disparo
        self.promedio_disparos += juego.tiros

    def top10_jugadores(self, usuarios):  # TOP 10 MEJORES JUGADORES
        self.top10 = sorted(usuarios, reverse=True)
        print("Top 10")
        for index in range(10):
            if index < len(self.top10):
                print(self.top10[index].info_top())
            else:
                break

    def top10_juegos(self, juegos):  # TOP 10 MEJORES JUEGOS

        self.top10 = sorted(juegos, key=operator.attrgetter('puntaje'), reverse=True)

        print("Top 10")
        for index in range(10):
            if index < len(self.top10):
                print(self.top10[index].info_top())
            else:
                break

    def archivo(self):
        informacion = "\nJuegos por rango de edades:\n"
        for rango in self.rango_edades.keys():
            informacion += rango + ": "+str(self.rango_edades[rango]) + "\n"

        informacion += "\nPuntos por genero:\n"
        for rango in self.puntos_generos.keys():
            informacion += rango + ": "+str(self.puntos_generos[rango]) + "\n"
        informacion += "\nPromedio de disparos: "+ str(self.promedio_disparos)

        informacion+="\nTop10\n"
        for index in range(10):
            if index < len(self.top10):
                informacion += self.top10[index].info_top() + "\n"
            else:
                break
        return informacion