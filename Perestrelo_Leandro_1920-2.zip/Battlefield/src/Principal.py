from Estadisticas import Estadisticas
from Juego import Juego
from Usuario import Usuario

usuarios = []
juegos = []
usuario_actual = None
estadisticas = Estadisticas()
id_generador = 0

menu = "Ingrese 1 para modulo de usuario \n" \
       "Ingrese 2 para modulo de juego \n" \
       "Ingrese 3 para modulo de estadisticas \n" \
       "Ingrese 4 para guardar archivo \n" \
       "Ingrese 5 para salir"

menu_usuario = "Ingrese 1 para iniciar sesion \n" \
               "Ingrese 2 para editar \n" \
               "Ingrese 3 regresar al menu principal"


def modulo_usuario():  # MODULO DEL USUARIO
    opcion = 1
    opcion_valida = False
    while not opcion_valida:
        print(menu_usuario)
        opcion_str = input("su opción es:")
        if opcion_str.isnumeric():
            opcion = int(opcion_str)
            if opcion == 1:
                iniciar_sesion()
                opcion_valida = True
            elif opcion == 2:
                if usuario_actual is None:  # NO HA INICIADO SESION
                    print("No puede editar usuario sin iniciar sesion")
                else:
                    editar_usuario()
                    opcion_valida = True
            elif opcion == 3:
                print("Regresando al menu principal")
                opcion_valida = True
            else:
                print("Opción invalida, por favor ingrese una opción correcta")
        else:
            print("Opción invalida, por favor ingrese una opción correcta")


def validar_username(username):  # VALIDACION DEL USERNAME
    if len(username) > 30:
        return False
    if " " in username:
        return False
    if username.isupper():
        return False
    return True


def buscar_usuario(username):  # BUSCAR EL USERNAME EN LA LISTA DE USUARIOS
    for usuario in usuarios:
        if usuario.username == username:
            return usuario
    return None


def registrar_usuario(username):  # REGISTRO DE LOS USUARIOS
    global id_generador
    global usuario_actual
    nombre_completo_valido = False
    nombre_completo = None
    while not nombre_completo_valido:
        nombre_completo = input("Ingrese su nombre completo")
        if len(nombre_completo) != 0:
            palabras = nombre_completo.split(" ")
            nombre_completo_valido = True
            for palabra in palabras:
                if not palabra.isalpha():
                    nombre_completo_valido = False
                    print("Nombre inválido")
                    break
        else:
            print("Nombre inválido")
            nombre_completo_valido = False

    edad_valida = False
    edad = 0
    while not edad_valida:
        edad_str = str(input("Ingrese su edad"))
        if edad_str.isnumeric():
            edad = int(edad_str)
            if 0 < edad < 100:
                edad_valida = True
            else:
                print("Edad inválida")
                edad_valida = False
        else:
            print("Edad inválida")
    genero_valido = False
    genero = None
    while not genero_valido:
        genero_str = input("Ingrese su genero(F/M)")
        if genero_str.isalpha():
            genero = str(genero_str).upper()
            if genero == "F" or genero == "M":
                genero_valido = True
            else:
                print("Genero inválido")
                genero_valido = False
        else:
            print("Genero inválido")
    id_generador += 1
    usuario = Usuario(id_generador, username, nombre_completo, edad, genero)
    usuario_actual = usuario
    return usuario


def iniciar_sesion():  # INICIO DE SESION
    username = input("Ingrese su username")
    while not validar_username(username):
        print("Username invalido")
        username = input("Ingrese su username")

    usuario_actual = buscar_usuario(username)
    if usuario_actual is None:
        usuario_actual = registrar_usuario(username)
        usuarios.append(usuario_actual)


def validar_genero(genero):  # VALIDACION DEL GENERO
    return genero == "M" or genero == "F"


def editar_usuario():  # EDITAR UN USUARIO
    global  estadisticas
    nombre_completo_valido = False
    nombre_completo = None
    while not nombre_completo_valido:
        nombre_completo = input("Ingrese su nombre completo")
        if len(nombre_completo) != 0:
            palabras = nombre_completo.split(" ")
            nombre_completo_valido = True
            for palabra in palabras:
                if not palabra.isalpha():
                    nombre_completo_valido = False
                    print("Nombre inválido")
                    break
        else:
            print("Nombre inválido")
            nombre_completo_valido = False
    edad_valida = False
    edad = 0
    while not edad_valida:
        edad_str = str(input("Ingrese su edad"))
        if edad_str.isnumeric():
            edad = int(edad_str)
            if 0 < edad < 100:
                edad_valida = True
            else:
                print("Edad inválida")
                edad_valida = False
        else:
            print("Edad inválida")
    genero_valido = False
    genero = None
    while not genero_valido:
        genero_str = input("Ingrese su genero(F/M)")
        if genero_str.isalpha():
            genero = str(genero_str).upper()
            if genero == "F" or genero == "M":
                genero_valido = True
            else:
                print("Genero inválido")
                genero_valido = False
        else:
            print("Genero inválido")
    usuario_actual.nombre_completo = nombre_completo
    usuario_actual.edad = edad
    usuario_actual.genero = genero
    estadisticas = Estadisticas()
    estadisticas.recalcular_estadisticas(juegos)

def modulo_juego():  # MODULO DE JUEGO
    if usuario_actual is not None:
        salir = False
        while not salir:
            juego = Juego(usuario_actual)
            juego.inicializar()
            juegos.append(juego)
            juego.jugar()
            usuario_actual.puntaje_total += juego.puntaje
            usuario_actual.disparos += juego.tiros
            estadisticas.actualizar_estadisticas(juego)
            respuesta = str(input(" Desea volver a jugar? S/N")).lower()
            while respuesta != "s" and respuesta != "n":
                respuesta = str(input("Opcion invalida, desea volver a jugar? S/N")).lower()
            salir = respuesta == "n"
    else:
        print(" Debe iniciar sesion para poder jugar")


def modulo_estadisticas():  # MODULO DE ESTADISTICAS
    estadisticas.imprimir_estadisticas(len(juegos))


def main() -> object:  # MENU PRINCIPAL
    opcion = 0
    while opcion != 5:

        opcion_valida = False
        opcion = 0
        while not opcion_valida or 1 <= opcion <= 4:
            estadisticas.imprimir_top(juegos, usuarios)
            print(menu)
            opcion_str = input("su opcion es:")
            if opcion_str.isnumeric():
                opcion = int(opcion_str)
                if opcion == 1:
                    modulo_usuario()
                    opcion_valida = True
                elif opcion == 2:
                    modulo_juego()
                    opcion_valida = True
                elif opcion == 3:
                    modulo_estadisticas()
                    opcion_valida = True
                elif opcion == 4:
                    guardar_archivo()
                    opcion_valida = True
                elif opcion == 5:
                    print("Gracias por jugar Battleship")
                    opcion_valida = True
                else:
                    print("Opcion invalida, ingrese nuevamente su opcion")
                    opcion_valida = False
            else:
                print("Opcion invalida, ingrese nuevamente su opcion")


def guardar_archivo():  # GUARDAR ARCHIVO TXT
    archivo = open("battleship.txt", mode="w")
    archivo.write("Usuarios\n")
    for usuario in usuarios:
        archivo.write(usuario.archivo())

    archivo.write("\nJuegos\n")
    for juego in juegos:
        archivo.write(juego.archivo())
    archivo.write("\nEstadisticas\n")
    archivo.write(estadisticas.archivo())


main()
