from Embarcacion import Embarcacion


class Buque2(Embarcacion):
    def __init__(self):
        self.tamano = 2
        self.capacidad = "Tiene la capacidad de comunicarse con tierra y los otros miembros de la flota"
