from Embarcacion import Embarcacion


class Buque2(Embarcacion):

    def __init__(self): # EL BUQUE DE TAMANO 2
        self.tamano = 2
        self.capacidad = "Tiene la capacidad de comunicarse con tierra y los otros miembros de la flota"
