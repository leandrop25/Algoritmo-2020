from Embarcacion import Embarcacion

class Buque3(Embarcacion):
    def __init__(self):
        self.tamano = 3
        self.capacidad = "Tiene la capacidad de aterrizar helicopteros en el para el transporte de tropas"
