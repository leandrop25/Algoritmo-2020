from Flota import Flota
from Tablero import Tablero


class Juego:
    def __init__(self, usuario):
        self.usuario = usuario
        self.tablero = Tablero()
        self.flota = Flota()
        self.tiros = 0
        self.tiros_acertados = 0
        self.tiros_fallados = 0
        self.tiros_repetidos = 0
        self.puntaje = 0

    def inicializar(self):
        self.tablero.insertar_barcos(self.flota)

    def jugar(self):
        while self.tiros_acertados < 9:
            self.tablero.imprimir()
            x = input("Indique la fila que se encuentra")
            y = input("Indique la columna que se encuentra")

            if self.validar(x) and self.validar(y):
                fila = int(x)
                columna = int(y)
                self.tiros += 1
                if self.tablero.matriz[fila][columna] == "X" or self.tablero.matriz[fila][
                    columna] == "F":  # disparos repetidos
                    self.tiros_repetidos += 1
                    print("Disparo ya realizado")
                elif self.tablero.matriz[fila][columna] == "O":  # disparo fallados
                    self.tiros_fallados += 1
                    self.tablero.matriz[fila][columna] = "X"
                    print("Disparo fallado")
                    self.puntaje -= 2
                elif self.tablero.matriz[fila][columna] == "B":  # disparos acertados
                    self.tiros_acertados += 1
                    self.tablero.matriz[fila][columna] = "F"
                    print("Disparo acertado")
                    self.puntaje += 10
            else:
                print("Jugada invalida")
        self.mostrar_informacion()

    def mostrar_informacion(self):
        if self.tiros == 9:
            print("¿Eres un Robot? lo que acabas de hacer es poco probable ...")
        elif self.tiros < 45:
            print("Excelente Estrategia")
        elif 45 <= self.tiros < 70:
            print("Buena Estrategia, pero hay que mejorar")
        elif self.tiros >= 70:
            print("Considérese Perdedor, tiene que mejorar notablemente")
        print("Username: {}".format(self.usuario.username))
        print("Cantidad de disparos realizados: {}".format(self.tiros))
        print("Puntaje total: {}".format(self.puntaje))
        print("Cantidad de disparos repetidos: {}".format(self.tiros_repetidos))
        print("Matriz: ")
        self.tablero.imprimir()

    def imprimir_top(self):
        print("{} {} {}".format(self.usuario.id, self.puntaje, self.tiros))

    def validar(self, numero):
        if not numero.isnumeric():
            return False
        else:
            num = int(numero)
            if 0 <= num <= 9:
                return True
            return False

    def info_top(self):
        info = "id usuario: " + str(self.usuario.username) + " puntaje: " + str(self.puntaje) + " tiros: " + str(self.tiros)
        return info

    def archivo(self):
        informacion = "Id de usuario: " + self.usuario.username + " disparos: " + str(self.tiros) + " disparos acertados: " + str(self.tiros_acertados) + " disparos fallados: " + str(self.tiros_fallados) + " disparos repetidos: " + str(self.tiros_repetidos) + " puntaje: " + str(self.puntaje) + "\n"
        return informacion
