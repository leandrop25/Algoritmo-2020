class Usuario:
    def __init__(self, id, username, nombre_completo, edad, genero):
        self.id = id
        self.username = username
        self.nombre_completo = nombre_completo
        self.edad = edad
        self.genero = genero
        self.puntaje_total = 0
        self.disparos = 0

    def __int__(self):
        None

    def __cmp__(self, other):
        if self.puntaje_total < other.puntaje_total:
            rst = -1
        elif self.puntaje_total > other.puntaje_total:
            rst = 1
        else:
            rst = 0
        return rst

    def imprimir_top(self):
        print("{} {} {}".format(self.id, self.puntaje_total, self.disparos))

    def archivo(self):
        informacion = "id: " + str(self.id) + " username: " + self.username + " nombre completo: " + self.nombre_completo + " edad: " + str(self.edad) + " genero: " + self.genero + "\n"
        return informacion
