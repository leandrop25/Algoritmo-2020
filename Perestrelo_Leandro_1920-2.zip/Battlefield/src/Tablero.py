from random import randrange


class Tablero:
    def __init__(self): # MATRIZ
        self.matriz = []
        for x in range(10):
            self.matriz.append(["O"] * 10)

    def insertar_barcos(self, flota): # INSERTAR BARCOS
        for x in flota.embarcaciones:
            self.ubicar_barco(x)

    def ubicar_barco(self, embarcacion): # UBICAR BARCOS
        valida = False
        while (not valida):
            posicion = randrange(2)

            ubicacion = ()
            if posicion == 0:# HORIZONTAL
                ubicacion = (randrange(10), randrange(11 - embarcacion.tamano))
            else:
                ubicacion = (randrange(11 - embarcacion.tamano), randrange(10))

            valida = self.validar_posicion(posicion, ubicacion, embarcacion)
            if (valida):
                if posicion == 0:  # HORIZONTAL
                    for columna in range(ubicacion[1], ubicacion[1] + embarcacion.tamano):
                        self.matriz[ubicacion[0]][columna] = "B"
                else:  # VERTICAL
                    for fila in range(ubicacion[0], ubicacion[0] + embarcacion.tamano):
                        self.matriz[fila][ubicacion[1]] = "B"

    def validar_posicion(self, posicion, ubicacion, embarcacion): # VALIDACION DE POSICION DEL BARCO

        if posicion == 0:  # HORIZONTAL
            for fila in range(max(0, ubicacion[0] - 1), min(10, ubicacion[0] + 2)):
                for columna in range(max(0, ubicacion[1] - 1), min(10, ubicacion[1] + embarcacion.tamano + 1)):
                    if self.matriz[fila][columna] != "O":
                        return False
            return True
        else:  # VERTICAL
            for fila in range(max(0, ubicacion[0] - 1), min(10, ubicacion[0] + embarcacion.tamano + 1)):
                for columna in range(max(0, ubicacion[1] - 1), min(10, ubicacion[1] + 2)):
                    if self.matriz[fila][columna] != "O":
                        return False
            return True

    def imprimir(self): # IMPRIMIR MATRIZ
        print("   0 1 2 3 4 5 6 7 8 9")
        print("-----------------------")
        for fila in range(len(self.matriz)):
            print(fila, end="| ")
            for columna in range(len(self.matriz[0])):
                if self.matriz[fila][columna] == "B":
                    print("O", end=" ")
                else:
                    print(self.matriz[fila][columna], end= " ")
            print("")


