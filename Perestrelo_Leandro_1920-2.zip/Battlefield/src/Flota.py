from Buque2 import Buque2
from Buque3 import Buque3
from Submarino import Submarino


class Flota:
    def __init__(self):
        self.embarcaciones = [Buque3(), Buque2(), Submarino(), Submarino(), Submarino(), Submarino()]
