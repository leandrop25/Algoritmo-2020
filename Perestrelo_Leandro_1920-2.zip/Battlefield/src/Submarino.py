from Embarcacion import Embarcacion

class Submarino(Embarcacion):

    def __init__(self): # LOS SUBMARINOS
        self.tamano = 1
        self.capacidad = "Tiene la capacidad de poder sumergirse y emerger del agua"