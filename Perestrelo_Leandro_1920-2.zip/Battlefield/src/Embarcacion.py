class Embarcacion:
    def __init__(self):
        self.tamano = 0
        self.capacidad = ""

    def imprimir_capacidad(self):
        print(self.capacidad)